import 'package:flutter/material.dart';
class NewRoute extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("detail page"),
      ),
      body: Center(
        child: Text("This is page"),
      ),
    );
  }
}