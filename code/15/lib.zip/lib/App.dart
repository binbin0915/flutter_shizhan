import 'package:flutter/material.dart';
import './page/home.dart';

class MyApp extends StatelessWidget {
  // build()方法来描述如何构建UI界面
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      // MyHomePage` 是Flutter应用的首页
      home: MyHomePage(title: 'Flutter Demo Home Page'),
    );
  }
}

