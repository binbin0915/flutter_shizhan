import 'package:flutter/material.dart';
import 'App.dart';
// 导入了Material UI组件库
// 应用入口。`runApp` 方法是启动Flutter应用
void main() => runApp(MyApp());

